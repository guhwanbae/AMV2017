/*
 * driveController.c
 *
 *  Created on: 2017. 6. 29.
 *      Author: ghbae
 */

/*******************************************************************************
* Include
*******************************************************************************/
#include "global.h"
#include "vehicleController.h"
#include "cameraController.h"
#include "timerController.h"
#include "imageProcess.h"
#include <math.h>

/*******************************************************************************
* Constant
*******************************************************************************/
extern vehicleControl vehicle;

/*******************************************************************************
* Define & MACRO
*******************************************************************************/
#define THRESHOLD_JUDGE_CROSSING 30		//Degree

/*******************************************************************************
* Type Definition
*******************************************************************************/


/*******************************************************************************
* Exported Global Variables
*******************************************************************************/


/*******************************************************************************
* Memeber Functions
*******************************************************************************/
void setPurePursuit(edge edgeAngle) {
	double lengthWayPoint = (((double)CAM_PARAMETER_DISTANCE) / cos(edgeAngle));
	double curvature = (((double)2*sin(edgeAngle))/(lengthWayPoint));
	double servoArgument = atan(((double)VEHICLE_PARAMETER_LENGTH)*curvature);

	vehicle.purePursuit.servoArgument = servoArgument;
	vehicle.purePursuit.curCurvature = curvature;
	vehicle.purePursuit.lengthWayPoint = lengthWayPoint;
}

void judgeCrossCondition(edge leftEdgeAngle, edge rightEdgeAngle) {
	edge avgAngle = (leftEdgeAngle + rightEdgeAngle)/2;
	edge diffAngle = ABS(leftEdgeAngle-rightEdgeAngle);

	if(diffAngle < THRESHOLD_JUDGE_CROSSING) { //isFrontObstacle() üũ�ؾ���
		setPurePursuit(avgAngle);
		/* CASE STRAIGHT
		 * Go straight. ��� �޷��� . ���θ�� ->|   |   |		|   | \			 / |   |
		/*						        |   |   |	or	|   |  \	or  /  |   |
		/*                              |bov|   | 		|bov|   |		|  |bov| */
	}
	else if(avgAngle > 0) {
		if(leftEdgeAngle < avgAngle && avgAngle < rightEdgeAngle && isFrontObstacle() == TRUE) {
			/* CASE I
			/* Cross Right. ���������� ������ . ���θ�� -> | @ |   /
			/*					     	         |   |  /
			/*                                   |bov| / */
		}
		else if(leftEdgeAngle > avgAngle && avgAngle > rightEdgeAngle && isFrontObstacle() == FALSE) {
			/* CASE II
			/* Cross Right. ���������� ������ . ���θ�� ->    / |  |
			/*						               /  |  |
			/*                                    |bov|  | */
		}
	}
	else {
		if(leftEdgeAngle < avgAngle && avgAngle < rightEdgeAngle && isFrontObstacle() == TRUE) {
			/* CASE III
			 * Cross Left.  �������� �����. ���θ�� -> \   | @ |
			/*					     	        \  |   |
			/*                                   \ |bov| */
		}
		else if(leftEdgeAngle > avgAngle && avgAngle > rightEdgeAngle && isFrontObstacle() == FALSE) {
			/* CASE IV
			/* Cross Right. �������� �����. ���θ�� -> |   | \
			/*					     	       |   |  \
			/*                                 |   |bov| */
		}
	}
}

void setCameraData(angleRadianType leftEdgeAngle, angleRadianType rightEdgeAngle, lengthType calcedWidth, lengthType calibratedWidth) {
	vehicle.statusData.camData.curLeftEdgeAngle = leftEdgeAngle;
	vehicle.statusData.camData.curRightEdgeAngle = rightEdgeAngle;
	vehicle.statusData.camData.curLaneWidth = calcedWidth;
	vehicle.statusData.camData.curCompWidth = calibratedWidth;
}

void setKineticStatus(velocityType mps, rpmType rpm, angleRadianType steeringAngle) {
	vehicle.statusData.kinetic.curMps = mps;
	vehicle.statusData.kinetic.curRpm = rpm;
	vehicle.statusData.kinetic.curSteeringAngle = steeringAngle;
}
