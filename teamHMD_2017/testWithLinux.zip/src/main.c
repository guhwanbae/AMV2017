/*====================================================================
* Project:  Board Support Package (BSP) examples
* Function: empty main function
*
* Copyright HighTec EDV-Systeme GmbH 1982-2013
*====================================================================*/
#include <stdlib.h>
#include "systemController.h"
#include "vehicleController.h"
#include "cameraController.h"
#include "timerController.h"
#include "interrupts.h"
#include "imageProcess.h"
#include "steering.h"
#include "pwm.h"
#include "typedefinition.h"
#include "global.h"
int main(void)
{
	/*
	queue* newQ = newQueue(100);

	int index=0;

	for(index=0;index<100;++index) {
		enQueue(newQ,(keyType*)index);
	}

	for(index=0;index<100;++index) {
		deQueue(newQ);
	}
	*/

	systemInit();
	peripheralInit();
	peripheralOn();

	pwmDcMotor(45, 0);

	while(1)
	{
		P13_OUT.B.P0 = !P13_OUT.B.P0;
		P13_OUT.B.P1 = !P13_OUT.B.P1;
	}
	return EXIT_SUCCESS;
}
