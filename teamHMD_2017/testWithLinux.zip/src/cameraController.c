/*
 * cameraController.c
 *
 *  Created on: 2017. 6. 26.
 *      Author: ghbae
 */

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "global.h"
#include "typedefinition.h"
#include "cameraController.h"
#include "vehicleController.h"
#include "timerController.h"
#include "imageProcess.h"

/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/
#define SET_VALUE_LEFT_CAM_SI_PERIOD	GTM_TOM0_CH15_SR0.U
#define SET_VALUE_LEFT_CAM_SI_DUTY		GTM_TOM0_CH15_SR1.U
#define SET_VALUE_LEFT_CAM_CLK_PERIOD	GTM_TOM0_CH11_SR0.U
#define SET_VALUE_LEFT_CAM_CLK_DUTY		GTM_TOM0_CH11_SR1.U

#define SET_VALUE_RIGHT_CAM_SI_PERIOD	GTM_TOM0_CH2_SR0.U
#define SET_VALUE_RIGHT_CAM_SI_DUTY		GTM_TOM0_CH2_SR1.U
#define SET_VALUE_RIGHT_CAM_CLK_PERIOD	GTM_TOM0_CH12_SR0.U
#define SET_VALUE_RIGHT_CAM_CLK_DUTY	GTM_TOM0_CH12_SR1.U
/*******************************************************************************
 * Type Definition
 *******************************************************************************/
/* configuration of delay loop */

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
cameraStruct camera;
cameraStruct2D camera2D;

/*******************************************************************************
 * Memeber Functions
 *******************************************************************************/

void cameraInit(void) {
	//cameraStructInit();
	cameraStructInit2D();
}

void cameraStructInit(void) {
	camera.input.pixelInputCnt = 0;
	int index;
	for(index=0; index<CAMERA_INPUT_LENGTH; ++index) {
		camera.input.inputPixelArr[index] = 0;
	}
}

void cameraStructInit2D(void) {
	camera2D.input.inputHeight = IMAGE_HEIGHT - 1;
	camera2D.input.inputWidthCnt = 0;
	int h,w;
	for(h=0; h<IMAGE_HEIGHT; ++h) {
		for(w=0; w<IMAGE_WIDTH; ++w) {
			camera2D.input.inputImageArr[h][w] = 0;
		}
	}
}

void cameraClock(int periodSI, int dutySI, int periodCLK, int dutyCLK) {
	// Camera 1 SI (CAM LEFT)
	SET_VALUE_LEFT_CAM_SI_PERIOD	= periodSI; //Camera1_SI_Period
	SET_VALUE_LEFT_CAM_SI_DUTY		= dutySI;	//Camera1_SI_Duty

	// Camera 1 CLK (CAM LEFT)
	SET_VALUE_LEFT_CAM_CLK_PERIOD	= periodCLK;	//Camera1_CLK_Period
	SET_VALUE_LEFT_CAM_CLK_DUTY		= dutyCLK;		//Camera1_CLK_Duty

	// Camera 2 SI  (CAM RIGHT)
	SET_VALUE_RIGHT_CAM_SI_PERIOD	= periodSI;	//Camera2_SI_Period
	SET_VALUE_RIGHT_CAM_SI_DUTY		= dutySI;	//Camera2_SI_Duty

	// Camera 2 CLK (CAM RIGHT)
	SET_VALUE_RIGHT_CAM_CLK_PERIOD	= periodCLK;	//Camera2_CLK_Period
	SET_VALUE_RIGHT_CAM_CLK_DUTY	= dutyCLK;		//Camera2_CLK_Duty
}

void getPixel(int dummy) {
   if(camera.input.pixelInputCnt<=THRESHOLD_LEFT_ONLY) { // left only
      camera.input.inputPixelArr[camera.input.pixelInputCnt++] = READ_LEFT_CAMERA_PIXEL_FROM_ADC;
   }
   else if(camera.input.pixelInputCnt<=THRESHOLD_BOTH) // both
   {
      camera.input.inputPixelArr[camera.input.pixelInputCnt] = READ_LEFT_CAMERA_PIXEL_FROM_ADC;
      camera.input.inputPixelArr[(camera.input.pixelInputCnt)+SHIFT_PIXEL_INDEX] = READ_RIGHT_CAMERA_PIXEL_FROM_ADC;
      camera.input.pixelInputCnt++;
   }
   else if(camera.input.pixelInputCnt<=THRESHOLD_RIGHT_ONLY) {//right only
      camera.input.inputPixelArr[(camera.input.pixelInputCnt)+SHIFT_PIXEL_INDEX] = READ_RIGHT_CAMERA_PIXEL_FROM_ADC;
      camera.input.pixelInputCnt++;
   }
   else {
      return;
   }
}

void checkLinearProcess(int dummy) {
	linearImgProcess();

	/*	RESET CAMERA INPUT COUNT	*/
	camera.input.pixelInputCnt = 0;
}

void linearImgProcess(void) {
	pixel* inputArr = camera.input.inputPixelArr;
	pixel* resultArr = camera.result.resultProcessArr;

	/*	SMOOTHING? : noise removal algorithm
	 *	MEDIAN? : remove impulse noise.
	 * 	GAUSSIAN? : remove random noise. */
	linearSmoothing(inputArr,resultArr,CAMERA_INPUT_LENGTH-1);

	inputArr = resultArr;
	resultArr = camera.input.inputPixelArr;

	/*	GRADIENT? : differentiate signal. find edge.
	 *	SOBEL MASK? : differential operator in discrete. */
	linearGradient(inputArr,resultArr,CAMERA_INPUT_LENGTH-1);

	inputArr = resultArr;
	resultArr = camera.result.resultProcessArr;

	/*	NON-MAXIMUM-SURPRESSION? : 	*/
	linearNonMaximumSurpression(inputArr,resultArr,CAMERA_INPUT_LENGTH-1);

	inputArr = resultArr;
	resultArr = camera.result.resultProcessArr;

	/*	DOUBLE-THRESHOLDING? :	*/
	//linearDoubleThresholding(inputArr,resultArr,CAMERA_INPUT_LENGTH-1);
}

void buildFrame(int dummy) {
	if(camera2D.input.inputHeight >= 0 && camera2D.input.inputWidthCnt < IMAGE_WIDTH) {
		if(camera2D.input.inputWidthCnt <= THRESHOLD_LEFT_ONLY) {
			camera2D.input.inputImageArr[camera2D.input.inputHeight][camera2D.input.inputWidthCnt++] = READ_LEFT_CAMERA_PIXEL_FROM_ADC;
		}
		else if(camera2D.input.inputWidthCnt <= THRESHOLD_BOTH) {
			camera2D.input.inputImageArr[camera2D.input.inputHeight][camera2D.input.inputWidthCnt] = READ_LEFT_CAMERA_PIXEL_FROM_ADC;
			camera2D.input.inputImageArr[camera2D.input.inputHeight][(camera2D.input.inputWidthCnt)+SHIFT_PIXEL_INDEX] = READ_RIGHT_CAMERA_PIXEL_FROM_ADC;
			camera2D.input.inputWidthCnt++;
		}
		else if(camera2D.input.inputWidthCnt <= THRESHOLD_RIGHT_ONLY) {
			camera2D.input.inputImageArr[camera2D.input.inputHeight][(camera2D.input.inputHeight)+SHIFT_PIXEL_INDEX] = READ_RIGHT_CAMERA_PIXEL_FROM_ADC;
			camera2D.input.inputWidthCnt++;
		}
	}
	else if(camera2D.input.inputWidthCnt == IMAGE_WIDTH) {
		camera2D.input.inputHeight--;
	}
	else {
		return;
	}
}

void check2DProcess(int dummy) {
	if(camera2D.input.inputHeight == 0) {
		imgProcess2D();

		camera2D.input.inputHeight = IMAGE_HEIGHT - 1;
		camera2D.input.inputWidthCnt = 0;
	}
	else {
		camera2D.input.inputHeight--;
	}
}

void imgProcess2D(void) {
	/*	SMOOTHING? : noise removal algorithm
	 *	MEDIAN? : remove impulse noise.
	 * 	GAUSSIAN? : remove random noise. */
	//input(temp) : inputImageArr, result(temp) : edgeVal
	//median2D(camera2D.input.inputImageArr,camera2D.result.edgeVal,IMAGE_WIDTH,IMAGE_HEIGHT);
	gaussian(camera2D.input.inputImageArr,camera2D.result.edgeVal,IMAGE_WIDTH,IMAGE_HEIGHT);

	/*	GRADIENT? : differentiate signal. find edge.
	 *	SOBEL MASK? : differential operator in discrete. */
	//input(temp) : edgeVal, result(temp) : inputImageArr
	gradient(camera2D.result.edgeVal,camera2D.input.inputImageArr,camera2D.result.edgeDir,IMAGE_WIDTH,IMAGE_HEIGHT);

	/*	NON-MAXIMUM-SURPRESSION? : 	*/
	//input(temp) : inputImageArr, result(temp) : edgeVal
	nonMaximumSurpression(camera2D.input.inputImageArr,camera2D.result.edgeVal,IMAGE_WIDTH,IMAGE_HEIGHT);

	/*	DOUBLE-THRESHOLDING? :	*/
	//input(temp) : edgeVal, result(complete) : edgeVal
	//hysteresisThresholding(camera2D.result.edgeVal,camera2D.result.edgeVal,IMAGE_WIDTH,IMAGE_HEIGHT);//input(temp) : edgeVal, result(temp) : inputImageArr
}

