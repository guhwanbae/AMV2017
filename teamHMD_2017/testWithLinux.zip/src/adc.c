/*
 * adc.c
 *
 *  Created on: 2017. 6. 26.
 *      Author: ghbae
 */

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "global.h"
#include "cameraController.h"
#include "systemController.h"
#include "vehicleController.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

#define DISR_MODULE_CLK_EN		0
#define DISS_MODULE_BUSY		0
#define ANONC_MODE_NORMAL		0b11
#define ARBM_MODE_FREE_RUN		0
#define SUCAL_CALIB_RESET		1
#define DIVWC_WRITE_EN			1
#define REFPC_USE_VREF			1
#define LOSUP_SUPPLY_HIGH		0
#define DIVD_ADCD_DIVIDE		0b00
#define DIVA_ADCI_DIVIDE		0b00000
#define ASEN_SLOT_EN			1
#define ICLSEL_GBSP_CLASSZERO	0b00
#define REFSEL_VREF_STDINPUT	0
#define RESREG_RESULT_POS1      0b1001//RES9   RIGHT CAM
#define RESREG_RESULT_POS2      0b1011//RES11   LEFT CAM
#define RESREG_RESULT_POS3      0b0011//RES3   BOTTOM DMS
#define RESREG_RESULT_POS4      0b0101//RES5   TOP DMS
#define RESPOS_SORTED_LEFT		0

#define ITSEL_SCANREQ_SRC		0b01
#define SRDIS_ONLY_INTTRIG		1
#define SEL_PRIORITY_CH			1

#define ENGT_CONVREQ_ISS		0b01
#define ENTR_EXT_DIS			0
#define ENSI_INT_NOREQSRC		0
#define SCAN_AUTO_EN			1
#define LDM_MODE_OVERWR			0

#define SRCRESREG_RESULT_POS	0b0000
#define XTWC_WR_EN				1
#define GTWC_WR_EN				1
#define XTMODE_EVENT_RISINGEDGE	0b10

#define CONV_RESOLUTION_12BIT	0b000

#define THIS_CH_IGNORE			0x00000001
#define IGNORE_THIS_CH			0x00000402

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

/*******************************************************************************
 * Exported Functions
 * Function name: Camera_VADC_set
 * Description:	setting VADC
 *******************************************************************************/

void adcInit(void) {
	//AN9 RIGHT CAM G0_9
	//AN11 LEFT CAM G0_11

	//AN15   BOTTOM DMS G1_3
	//AN17  TOP      DMS G1_5
	UNLOCK_WDT_CON;
	VADC_CLC.B.DISR = DISR_MODULE_CLK_EN;
	while (VADC_CLC.B.DISS != DISS_MODULE_BUSY) {
		;
	}
	LOCK_WDT_CON;

	VADC_G1ARBCFG.B.ANONC = ANONC_MODE_NORMAL;
	VADC_G1ARBCFG.B.ARBM = ARBM_MODE_FREE_RUN;
	VADC_G0ARBCFG.B.ANONC = ANONC_MODE_NORMAL;
	VADC_G0ARBCFG.B.ARBM = ARBM_MODE_FREE_RUN;

	VADC_GLOBCFG.B.SUCAL = SUCAL_CALIB_RESET;
	VADC_GLOBCFG.B.DIVWC = DIVWC_WRITE_EN;
	VADC_GLOBCFG.B.REFPC = REFPC_USE_VREF;
	VADC_GLOBCFG.B.LOSUP = LOSUP_SUPPLY_HIGH;
	VADC_GLOBCFG.B.DIVD = DIVD_ADCD_DIVIDE;
	VADC_GLOBCFG.B.DIVA = DIVA_ADCI_DIVIDE;

	VADC_G1ARBPR.B.ASEN1 = ASEN_SLOT_EN;
	VADC_G0ARBPR.B.ASEN1 = ASEN_SLOT_EN;

	//LEFT CAM
	VADC_G0CHCTR11.B.ICLSEL = ICLSEL_GBSP_CLASSZERO;
	VADC_G0CHCTR11.B.REFSEL = REFSEL_VREF_STDINPUT;
	VADC_G0CHCTR11.B.RESREG = RESREG_RESULT_POS1;
	VADC_G0CHCTR11.B.RESPOS = RESPOS_SORTED_LEFT;

	//RIGHT CAM
	VADC_G0CHCTR9.B.ICLSEL = ICLSEL_GBSP_CLASSZERO;
	VADC_G0CHCTR9.B.REFSEL = REFSEL_VREF_STDINPUT;
	VADC_G0CHCTR9.B.RESREG = RESREG_RESULT_POS2;
	VADC_G0CHCTR9.B.RESPOS = RESPOS_SORTED_LEFT;

	//BOTTOM DMS
	VADC_G1CHCTR3.B.ICLSEL = ICLSEL_GBSP_CLASSZERO;
	VADC_G1CHCTR3.B.REFSEL = REFSEL_VREF_STDINPUT;
	VADC_G1CHCTR3.B.RESREG = RESREG_RESULT_POS3;
	VADC_G1CHCTR3.B.RESPOS = RESPOS_SORTED_LEFT;

	//TOP DMS
	VADC_G1CHCTR5.B.ICLSEL = ICLSEL_GBSP_CLASSZERO;
	VADC_G1CHCTR5.B.REFSEL = REFSEL_VREF_STDINPUT;
	VADC_G1CHCTR5.B.RESREG = RESREG_RESULT_POS4;
	VADC_G1CHCTR5.B.RESPOS = RESPOS_SORTED_LEFT;

	VADC_G1TRCTR.B.ITSEL = ITSEL_SCANREQ_SRC;
	VADC_G1TRCTR.B.SRDIS = SRDIS_ONLY_INTTRIG;
	VADC_G0TRCTR.B.ITSEL = ITSEL_SCANREQ_SRC;
	VADC_G0TRCTR.B.SRDIS = SRDIS_ONLY_INTTRIG;

	VADC_G0CHASS.B.ASSCH11 = SEL_PRIORITY_CH;
	VADC_G0CHASS.B.ASSCH9 = SEL_PRIORITY_CH;
	VADC_G1CHASS.B.ASSCH3 = SEL_PRIORITY_CH;
	VADC_G1CHASS.B.ASSCH5 = SEL_PRIORITY_CH;

	VADC_G0RRASS.B.ASSRR11 = SEL_PRIORITY_CH;
	VADC_G0RRASS.B.ASSRR9 = SEL_PRIORITY_CH;
	VADC_G1RRASS.B.ASSRR3 = SEL_PRIORITY_CH;
	VADC_G1RRASS.B.ASSRR5 = SEL_PRIORITY_CH;

	VADC_G1ASMR.B.ENGT = ENGT_CONVREQ_ISS;
	VADC_G1ASMR.B.ENTR = ENTR_EXT_DIS;
	VADC_G1ASMR.B.ENSI = ENSI_INT_NOREQSRC;
	VADC_G1ASMR.B.SCAN = SCAN_AUTO_EN;
	VADC_G1ASMR.B.LDM = LDM_MODE_OVERWR;

	VADC_G0ASMR.B.ENGT = ENGT_CONVREQ_ISS;
	VADC_G0ASMR.B.ENTR = ENTR_EXT_DIS;
	VADC_G0ASMR.B.ENSI = ENSI_INT_NOREQSRC;
	VADC_G0ASMR.B.SCAN = SCAN_AUTO_EN;
	VADC_G0ASMR.B.LDM = LDM_MODE_OVERWR;

	VADC_G1ASCTRL.B.SRCRESREG = SRCRESREG_RESULT_POS;
	VADC_G1ASCTRL.B.XTWC = XTWC_WR_EN;
	VADC_G1ASCTRL.B.GTWC = GTWC_WR_EN;
	VADC_G1ASCTRL.B.XTMODE = XTMODE_EVENT_RISINGEDGE;

	VADC_G0ASCTRL.B.SRCRESREG = SRCRESREG_RESULT_POS;
	VADC_G0ASCTRL.B.XTWC = XTWC_WR_EN;
	VADC_G0ASCTRL.B.GTWC = GTWC_WR_EN;
	VADC_G0ASCTRL.B.XTMODE = XTMODE_EVENT_RISINGEDGE;

	VADC_G1ICLASS0.B.CMS = CONV_RESOLUTION_12BIT;
	VADC_G0ICLASS0.B.CMS = CONV_RESOLUTION_12BIT;

	VADC_G1ASSEL.U = THIS_CH_IGNORE;
	VADC_G0ASSEL.U = IGNORE_THIS_CH;

	VADC_G1ASPND.U = THIS_CH_IGNORE;
	VADC_G0ASPND.U = IGNORE_THIS_CH;
}
