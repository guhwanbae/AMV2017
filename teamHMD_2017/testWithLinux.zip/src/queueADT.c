/*
 * queueADT.c
 *
 *  Created on: 2017. 6. 27.
 *      Author: ghbae
 */

/*******************************************************************************
* Include
*******************************************************************************/
#include "queueADT.h"
#include <stdio.h>
#include <stdlib.h>

/*******************************************************************************
* Constant
*******************************************************************************/


/*******************************************************************************
* Define & MACRO
*******************************************************************************/


/*******************************************************************************
* Type Definition
*******************************************************************************/


/*******************************************************************************
* Exported Global Variables
*******************************************************************************/

/*******************************************************************************
* Memeber Structures
*******************************************************************************/

/*******************************************************************************
* Memeber Functions
*******************************************************************************/
queue* newQueue(int newSize) {
	queue* newQueue = (queue*)malloc(sizeof(queue));
	queueInit(newQueue,newSize);
	return newQueue;
}

void deleteQueue(queue* pq) {
	queueDistroy(pq);
	free(pq);
}

void queueInit(queue* pq, int newSize) {
	pq->front	= 0;
	pq->rear	= 0;
	pq->size	= newSize;
	pq->Q = (keyType**)malloc(sizeof(keyType*)*pq->size);
	int index;
	for(index=0;index<pq->size;++index) {
		pq->Q[index] = NULL;
	}
}

void queueDistroy(queue* pq) {
	int index;
	for(index=0;index<pq->size;++index) {
		pq->Q[index] = NULL;
	}
	free(pq->Q);
	pq->Q = NULL;
}

bool queueIsEmpty(queue* pq) {
	if(pq->front == pq->rear) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

bool queueIsFull(queue* pq) {
	if(((pq->rear + 1) % QUEUE_SIZE) == pq->front) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

void enQueue(queue* pq, keyType* keyVal) {
	if(queueIsFull(pq) == TRUE) {
		return;
	}
	pq->rear = (pq->rear + 1) % QUEUE_SIZE;
	pq->Q[pq->rear] = keyVal;
}

keyType* deQueue(queue* pq) {
	if(queueIsEmpty(pq) == TRUE) {
		return FALSE;
	}
	pq->front = (pq->front + 1) % QUEUE_SIZE;
	return pq->Q[pq->front];
}

