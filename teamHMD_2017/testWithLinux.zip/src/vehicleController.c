/*
 * vehicleController.c
 *
 *  Created on: 2017. 6. 26.
 *      Author: ghbae
 */

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "global.h"
#include "vehicleController.h"
#include "cameraController.h"
#include "timerController.h"

/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Global Variables
 *******************************************************************************/
vehicleControl vehicle;

/*******************************************************************************
 * Memeber Functions
 *******************************************************************************/

void peripheralInit(void) {
	adcInit();
	timerOutputModuleInit();
	timerInputModuleInit();

	cameraInit();
}

void peripheralOn(void) {
	cameraClock(CAM_PERIOD_SI, CAM_DUTY_SI, CAM_PERIOD_CLK, CAM_DUTY_CLK);
	pwmServo(31250, 0);
}

void pwmServo(int servo0, long double servo_angle) {
	GTM_TOM1_CH0_SR0.U = servo0; //31250
	//2332.5       + left
	GTM_TOM1_CH0_SR1.U = 2376.5 + servo_angle * 16; // ���ͳݻ󿡼� ���´�� 1���� 10 usec  //2812.5      2652.5
} //2295

void pwmDcMotor(long double motor0, long double motor1) {
	P02_OUT.B.P0 = 1;
	P00_OUT.B.P2 = 1;

	GTM_TOM1_CH9_SR0.U = 300;
	GTM_TOM1_CH9_SR1.U = motor0;

	GTM_TOM1_CH2_SR0.U = 300;
	GTM_TOM1_CH2_SR1.U = motor1;
}
