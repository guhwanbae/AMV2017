/*
 * global.h
 *
 *  Created on: 2017. 6. 26.
 *      Author: ghbae
 */

#include "tc23xa/IfxPort_reg.h"
#include "tc23xa/IfxStm_reg.h"
#include "tc23xa/IfxVadc_reg.h"
#include "tc23xa/IfxGtm_reg.h"
#include "tc23xa/IfxScu_reg.h"
#include "tc23xa/IfxGpt12_reg.h"
#include <machine/wdtcon.h>

#ifndef PHI
#define PHI 3.1415
#endif

#ifndef RECT_RADIAN
#define RECT_RADIAN 1.571
#endif
