/*
 * imageProcess.h
 *
 *  Created on: 2017. 6. 27.
 *      Author: ghbae
 */

#ifndef IMAGEPROCESS_H_
#define IMAGEPROCESS_H_

/*******************************************************************************
* Include
*******************************************************************************/
#include "typedefinition.h"
#include "cameraController.h"

/*******************************************************************************
* Constant
*******************************************************************************/


/*******************************************************************************
* Define & MACRO
*******************************************************************************/
#define ABS(x)						(((x)<0)?-(x):(x))
#define DISTANCE_MANHATTAN(x,y)		(((x)<0)?(-(x)):(x))+(((y)<0)?(-(y)):(y))

/*******************************************************************************
* Type Definition
*******************************************************************************/

/*******************************************************************************
* Exported Global Variables
*******************************************************************************/


/*******************************************************************************
* Member Functions
*******************************************************************************/
/*SMOOTHING*/
//void median2D(pixel(*img)[IMAGE_WIDTH], pixel (*result)[IMAGE_WIDTH], int width, int height);
void median2D(int width, int height, pixel(*img)[width], pixel (*result)[width]);
void gaussian(int width, int height, pixel (*img)[width], pixel (*result)[width]);

/*FIND GRADIENT*/
void gradient(int width, int height, pixel (*img)[width], pixel (*result)[width], edge (*direction)[width]);

/*FIND EXTREMA*/
void nonMaximumSurpression(int width, int height, pixel (*img)[width], pixel (*result)[width]);
void hysteresisThresholding(int width, int height, pixel (*img)[width], pixel (*result)[width]);

/*VERSATILE FUNCTION*/
void median(pixel* arr, int start, int end);
pixel medianSort(pixel* arr, int start, int end);

/*LINEAR PROCESS*/
void linearSmoothing(pixel* arr, pixel* result, int end);
pixel* linearMedian(pixel* arr, pixel* result, int end);
pixel* linearGaussian(pixel* arr, pixel* result, int end);
pixel* linearGradient(pixel* arr, pixel* result, int end);
pixel* linearNonMaximumSurpression(pixel* arr, pixel* result, int end);
pixel* linearDoubleThresholding(pixel* arr, pixel* result, int end);

#endif /* IMAGEPROCESS_H_ */
