/*
 * vehicleController.h
 *
 *  Created on: 2017. 6. 26.
 *      Author: ghbae
 */

#ifndef VEHICLECONTROLLER_H_
#define VEHICLECONTROLLER_H_

/*******************************************************************************
* Include
*******************************************************************************/
#include "typedefinition.h"

/*******************************************************************************
* Constant
*******************************************************************************/


/*******************************************************************************
* Define & MACRO
*******************************************************************************/
#define SINGLE_LANE 1
#define FROM_SINGLE_LANE_TO_DOUBLE -1
#define	DOUBLE_LANE 2
#define FROM_DOUBLE_LNAE_TO_SINGLE -2
#define NO_WAY_ON_AEB 8411

#define VEHICLE_ON_LEFT_LANE -2
#define VEHICLE_FROM_LEFT_TO_RIGHT_LANE -1
#define VEHICLE_ON_SINGLE_LANE 0
#define VEHICLE_FROM_RIGHT_TO_LEFT_LANE 1
#define VEHICLE_ON_RIGHT_LANE 2

#define CURVED_LEFT_LANE -1
#define STRAIGHT_LALE 0
#define CURVED_RIGHT_LANE 1
#define ZIGZAG_LANE 2
#define NO_WAY_STOP 8411

#define DRIVE_DYNAMIC 1
#define DRIVE_SCHOOLZONE 0

#define VEHICLE_PARAMETER_LENGTH 40

/*******************************************************************************
* Type Definition
*******************************************************************************/
typedef double rpmType;
typedef double lengthType;
typedef double angleRadianType;
typedef double velocityType;

/*******************************************************************************
* Exported Global Variables
*******************************************************************************/

/*******************************************************************************
* Memeber Structures
*******************************************************************************/
/*

typedef struct location{
	double left;
	double central;
	double right;
}location;

typedef struct position{
	int lanePosition;
	location curLocation;
}position;

typedef struct environment{
	int roadCondition;
	int roadType;
}environment;

typedef struct driveVector{
	double curDirection;
	double curSpeed;
}driveVector;

typedef struct status{
	driveVector curDriveVector;
	int curRotation;
	int curRpm;
	int curMechanicalAngle;
	int curDriveMode;
}status;

typedef struct vehicleControl{
	position curPosition;
	environment	curEnvironment;
	status curStatus;
}vehicleControl;


 */

typedef struct purePursuit {
	lengthType lengthWayPoint;
	angleRadianType curCurvature;
	angleRadianType servoArgument;
}purePursuit;

typedef struct kineticStatus {
	rpmType curRpm;	/* Unit : rpm	*/
	velocityType curMps; /*	Unit : m/s */
	angleRadianType curSteeringAngle; /* Unit : radian	*/
}kineticStatus;

typedef struct cameraData {
	angleRadianType curLeftEdgeAngle;
	angleRadianType curRightEdgeAngle;
	lengthType curLaneWidth;
	lengthType curCompWidth;	/*	Calibrated	Width	*/
}cameraData;

typedef struct vehicleStatus {
	cameraData camData;
	kineticStatus kinetic;
}vehicleStatus;

typedef struct vehicleControl {
	vehicleStatus statusData;
	purePursuit purePursuit;
}vehicleControl;

/*******************************************************************************
* Memeber Functions
*******************************************************************************/
void peripheralInit(void);

void adcInit(void);
void pwmServo(int servo0, long double servo_angle);
void pwmDcMotor(long double motor0, long double motor1);
void peripheralOn(void);

#endif /* VEHICLECONTROLLER_H_ */
